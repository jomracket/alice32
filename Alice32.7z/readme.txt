Turn Word Wrap ON if you're using Notepad.
This is the Quick Start document.

See also the readme_alice.txt in the docs directory.

First, unzip the files into a directory, e.g. c:\Emulators\Malice

Then double-click on the Alice32 icon.

The emulator should now be running.

From the file menu, select Quick Type..., and from the quicktyp/GraphicFun directory, open sparkle.txt.

type run

When you've finished enjoying the colorful display, hit your PC's ESC key.
Then, go and read the readme_alice.txt that's in the DOCS directory!

You can Quicktype other program text files too.

CLOAD works on C10 files and a couple of other Alice cassette image file types.  For more information about those, see the readme_alice.txt that's in the DOCS directory, and the readme_c.txt that's in the cassette directory.

For more information about the Alice 32 computer, please visit these websites:
http://alice32.free.fr/
http://membres.lycos.fr/romualdl/alice/alice.html
www.google.com (and search for matra hachette alice)


Enjoy!
James the Animal Tamer
January 2006
www.geocities.com/emucompboy
