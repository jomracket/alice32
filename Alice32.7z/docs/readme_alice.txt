Turn Word Wrap ON if you're using Notepad.

My First Alice32 Emulator for Windows98, by James the Animal Tamer, emucompboy@yahoo.com

Now that there are two Alice 32 emulators, this name has stuck.  The other emulator is DCAlice.  If you haven't already visited the DCAlice website, you should visit it now.  http://alice32.free.fr/
Really.  Right now.  Don't wait.
It's an excellent collection of documentation and resources for the Alice 32 and Alice 90 computers.  Almost all the software in the K7-FR directory was taken from this site.  DCAlice sets the standards for Alice 32 emulators.  Also check out these sites:
http://membres.lycos.fr/romualdl/alice/alice.html
http://ritchy.free.fr/_musee.html#



QUICK START:
===========
How do I get started?
	Double click the Alice32 icon!
	Now you can type your program in.  You can CSAVE it via 
CSAVE "filename"
just as you would if you were using a real Alice 32 system.
	You can RUN your program.
	Wow.  Okay.  Suppose you want to load your program back in?  Type CLOAD.  Then from the File menu, select Play Cassette File.  From the dialog box which pops up, select your program!
	Remember, to load, always type CLOAD first, then select the Play Cassette File from the File menu.
	I like Quicktype better than the cassette stuff.  To use Quicktype, write your BASIC program using Notepad.  Save it.  Then use Quicktype from the File menu, and select the file you just saved.  My First Alice32 will enter it just as if you had typed it!
	This emulator archive contains several cassette image files (.C10 and .K7) and several Quicktype text files (.txt).


HOME PAGE:
==========
www.geocities.com/emucompboy
Home of the Virtual Aquarius

CONTACT:
========
emucompboy@yahoo.com

NOTE to ROM IMAGE COLLECTORS:
=============================
Okay, this is a change from my previous policy, so read it!
1.  It's okay to put the emulator archive up for download on your website.  If you do put it up, I ask that you include on your website a link to James the Animal Tamer's Emulators (www.geocities.com/emucompboy), as this emulator's home page.  The emulators are works in progress, and I will randomly be updating them, and not necessarily notifying you about it.
2.  You may not charge money for my work.
3.  You may not include any of my emulators or any of my content on any collection or compilation for which you intend to charge money (unless you plan on sending some money to me, Microsoft, Tandy, Panasonic, Matra & Hachette, and any other relevant copyright or license holders).
4.  I'd prefer that you do not unbundle software or other files that are contained within one of my emulator archives.  That said, I'd be pleased if you make enhanced variants on the computer software and offer those up on your own site.  I'd be MIGHTILY PLEASED if you'd take the "Checkers" or "Calculator" programs from the Virtual MC10 archive, and fix their input to be less retarded.
5.  Oh, please don't link directly to the file names on my site.  I change them with each upate!
Thanks.


System Requirements:
====================
Celeron 400MHz or faster recommended
Windows98 or newer
DirectX 6 or newer
Sound card compatible with DirectX
Fast video card with good appropriate video driver 
Display set to "high color" or "16-bit color" (32768 or 65536 colors) or "True color" or "24 bit color" or "32 bit color"

The emulator will run on slower computers, but probably not at full speed.  The emulator will run with the display settings set to something other than high color, but probably not at full speed, and probably the colors won't look right.  With my Voodoo3 display, the emulator works great in 24-bit and 32-bit modes.  In 256-color mode, it's slow and the colors don't look right.  In 16-color mode, it's really REALLY slow, and the colors look terrible!


Known Bugs
==========
1.  You must configure the printer filename before trying to LPRINT
2.  Some of the interrupts don't work (no one's come up with software that needs 'em)
3.  The implementation of some of the 6803 registers in the $0000-$001F address range is totally fake.  Totally.
4.  Baud rate pokes, and all other aspects of hardware serial I/O, don't work.  Did I mention that the 6803 registers are totally faked?
5.  The sound gets unpleasant overtones at higher frequencies.
6.  It's not finished.  If a feature you need is missing, contact me, emucompboy@yahoo.com
	Previous winners of the Missing Feature Contest:
	Romualdl, for pointing out that the Alice 32 has 16 colors, not 8
7.  In particular, the video chip implementation is incomplete and imperfect -- Some video commands are not implemented.  Some which are may not be properly implemented.  Some video modes are not correctly implemented.
8.  The 80-column mode looks nice on the PC screen but is not an accurate emulation.  The real computer uses 6x10 character cells in 80-column modes.  My First Alice32 uses 8x10.  This is generally a non-issue, since the Alice doesn't have dot graphics in these modes.
9.  In the Quicktype/ForNerds directory, there's a program called "testsomedh.txt" which is a testing sandbox.  Running this program, my First Alice32 doesn't do everything that a real Alice 32 would.  Oh, and, caveat:  I am not responsible for anything that happens to your monitor or computer if you try running this program (or any other program, for that matter) on a real Alice 32/90 computer.
10.  The sound and CPU speeds are not exactly matched.  During periods of silence, the emulator will attempt to resynch them.  If there aren't periods of silence, then sound and CPU will become increasingly out of synch, eventually leading to awful static.  Looking at the ABOUT box will force a resynch.
11.  The emulator is a CPU hog.  When running the emulator, hvaing other CPU hogs running will prevent the emulator from running at a constant speed.  CPU hogs include but are not limited to any Microsoft Office product, Microsoft Outlook, any internet browser program, 'instant messenger' programs, internet telephone programs, pop-up blockers, virus/spyware scanners, some obnoxious screensavers, viruses, rootkits, worms, spyware, adware, other emulators.  Beware, some of these hogs will have installed themselves so that they will run when Windows starts up, and/or so that if run once, they'll still be running at 'stand-by' even if you've closed the program.  To summarize, if your desktop tray is loaded with gadgets that notify you of some event or animate or periodically do something, then the emulator will not be running at a constant 99-100% speed reliably no matter how fast your CPU is.


Unknown Bugs
============
1.  Gosh how should I know?  They're unknown, right?  When you find them, contact me, emucompboy@yahoo.com
	Maybe you'll win the Missing Feature contest!
2.  Most things haven't been tested.
3.  If you see bugs, let me know.
4.  If you have a short BASIC program which runs differently on the emulator than it does on the real computer, send me a copy, and maybe I'll make the emulator better.


Known issues:
=============
These K7 software packages need the +24K expander setting:
	Galixian
	Incrustation-Video

Note that "Incrustation-Video" uses a hardware video overlay feature built into the Alice 90.  My First Alice32 does not emulate video overlay (the overlay bit is used to get 16 colors instead of 8, in the emulators).  Note the name "My First Alice32 Emulator" which isn't My First Alice90... you get the idea.

The copy of Le-sphinx-d-or-Alice.k7 on the DCAlice website is apparently non-conforming, and will not work with My First Alice32.  The copy included in this emulator archive has been patched to conform.



Preliminary Note:
=================
Here's My First Alice32 Emulator version 0.40.  It's fun and useful, but missing some features of the EF9345 video chip.

An important feature in this version is Quicktype (from the file menu).  This automatically types a text file.  The best way to use this is to edit a BASIC program as a text file using NOTEPAD.  Save it (from NOTEPAD).  Then use Quicktype to load it into My First Alice32.  This is much easier than trying to type in a program on the emulator itself (although that can be done).

If you simply prefer to use the emulator's keyboard, you can later use Quicktype.  LLIST your program, then use NOTEPAD to extract your program from the printer output file.  Save out the extracted program to another text file, and you can use the Quicktype feature to load that in.



What works:
=====================
CPU (instruction set)
Memory (with configuration)
Keyboard (emulated and sensible;  can be configured)
Quicktype (provides a means of loading in BASIC programs from text files)
LPRINT/LLIST (To file.)
BASIC CLOAD (C10 files and some WAV files;  some support for K7 multi-file cassette images)
BASIC CSAVE (C10 files)
Character set
Video border
Sound (mostly working)
Accurate timing (close enough)
Optional loading of other ROM OS
Utility save for memory as .c10
Joysticks
Paste from clipboard as Quicktype
Full screen mode

What does NOT work:
=====================
Some Video chip features
CPU (microcontroller features)
CPU (undocumented opcodes)
Timers (working just enough so Sound works)
Interrupts (count/compare works, others don't)
Other peripherals (were there any?)
Serial I/O
Changing of video mode mid-screen
Window size configuration
Optional loading of other character set


What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
Everything that doesn't work
Drag and drop of supported file types (don't hold your breath)
Better implementation of the top-of-form timer, flag, and interrupt
Have some facility for loading in hex dumps or Intel Hex or S-Record files.
Simple debugger
LST-level debugger
CSAVE/CLOAD TPD files (TPD stands for Tape Pulse Data)
Utility save for memory as .bin
Triple check unconnected memory implementation
Printer output sometimes gets garbled
Make the keyboard configuration interface more friendly
Joystick configuration (right now it just grabs the first two joysticks, and the first six buttons on each)
Emulate the pen-platen plotter (don't hold your breath)
Put the emulator on a separate thread so the program will be more system-friendly.


NOTES:
=====================
1.  Keyboard.  The keyboard operates in one of two modes:  Emulated or Sensible.  Emulated mode is most like the real Alice32 keyboard;  use this mode for playing games.  Sensible makes it easier to type from the PC keyboard.  You can switch back and forth in the same session.
My First Alice32 is set up to use a PC's QWERTY keyboard in emulated mode (you can reconfigure Sensible mode).  No one's told me yet that this isn't working out for his or her AZERTY keyboard (I use a Windows call to determine the key mapping.  If there's a problem here, then there's a problem with Windows).

2.  CLOAD.
To CLOAD a cassette image file from BASIC, first type
CLOAD [enter]
Then select Play Cassette File... from the File menu, and choose your .C10 or .WAV or .K7 cassette file.
Note that WAV files must be in 8-bit MONO format.  For best results, the WAV file should be 44,100 or 22,050 samples per second, although other speeds can be read.
NOTE:  the file loaded in this manner MUST have one of those extensions.  K7 files are multi-file tape images.  C10 files are the native Alice single-file tape images - this format is shared with the MC-10 computer.  CAS files are similar single-file tape images intended for the Radio Shack Color Computer (not that that helps -- the BASIC tokens are different, so loading one of these will yield gibberish).

3.  Sound.  Uses DirectSound from DirectX6.  It is mostly working.  Known problems include:  The Directsound and CPU emulation are not perfectly in sync, so there can be static.  Note that if your computer is not running the emulator at a fairly steady 100%, then the sound won't be right and may have problems.  The sound can be VERY LOUD;  in the Sound Configuration box, the default is 50%.  I recommend you don't make it any louder (I am not responsible for damage to your speakers in any case).

4.  Full Screen.  Uses DirectDraw from DirectX6.  F12 to toggle full screen mode.

5.  Joysticks.  Uses DirectInput.  It should work with any joystick that's properly installed under Windows.  If you have only one PC joystick, then it will be used for both Alice joysticks.  It's a feature, not a bug (because software doesn't agree on which player is 'player 1').  If you want two joysticks, go buy two PC joysticks.  They're only $10 each at Fry's.  What are you waiting for?

6.  Quicktype
	Quicktype can load in lower case as inverse video, and it can load in the graphic set as well (it's a cheat), thus enabling quicktyping even of such graphic-intense BASIC programs as Checkers.  The ability to quicktype lower case as inverse video is configurable from the keyboard configuration box.  You can convert your old text files by unchecking the lower case box, quicktyping your files, and LLISTing them.  Then cut and paste from the LPRINT.TXT file to get your new files.


Versions:
=========
January 28, 2006
	Bumped version to 0.40, official release.  It's mostly working and has all the features that Virtual MC-10 0.69c and Virtual Aquarius 0.72 have.
	Fixed one full screen bug, and put the EXEC address in the right place.

January 13, 2006
	Test version on my site, 0.01cT1.  Now supports K7 multi-file cassette images.  Plays most 40-column games.

March 14, 2005
	Update to the emulator, now version 0.01b.  Improvements to sound, and now full screen mode on the F12 key.

October 18, 2004
	Update to the emulator.  Now shows all 16 colors.  Emulates the simulation of semigraphics SG4 too.

October 12, 2004
	First preliminary version of My First Alice32 Emulator posted to James the Animal Tamer's Emulators.

	

Credits
=======
Me (James the Animal Tamer) -- I put together the emulator, the emulator archive, some docs, some test programs (both .C10 and Quicktype).

6803:	Portable 6803 emulator.  The author isn't mentioned, though his initials are HJB.  (I grabbed this from MAME)

Daniel Coulom:	information and inspiration.  He is the author of DCAlice, the other Alice 32 emulator.  His site is a great source of documentation on the Alice computers -- http://alice32.free.fr/

Microsoft	DirectX, Microsoft Visual C++, Microsoft Development Studio, Windows 95/98. 		 Thanks, Bill.

ROMs, cassette images, and Quicktype text files:	See those or their readmes for their respective credits.

The real Alice 32 computer:  	Matra & Hachette.  Thanks for making the computer, guys.

The real TRS-80 Microcolor Computer MC-10:	Tandy.  Thanks for making the computer, guys.

Documentation and programs:
	Lifted, looted, and borrowed from several sources!  Here are some of my heroes:

	http://alice32.free.fr/
		Daniel Coulom's Alice 32/90 website.  It has just about all the documentation and software that exists for the Alice 32 computer.  (I grabbed the K7 cassette image files from this website).

	http://www.maltedmedia.com/6803/
		6803 data sheet 

	http://www.burgins.com/emulators.html
		PC Dragon version 2.06 -- home of Dragon Convert (dc.exe)

	http://www.dragon-archive-online.co.uk/software/initial.htm
		Instructions for digitizing tape

	http://www.geocities.com/emucompboy
		James the Animal Tamer's Emulators
		Home of the Virtual Aquarius
		Each emulator archive contains an emulator and some software!

	Also google these terms:  TASM and DASMX


Random Jottings
===============
1.  What is an Alice 32?

A successor to the Ordinateur Alice.  The Ordinateur Alice was an MC-10 computer adapted by Matra & Hachette for France.  The MC-10 computer, "TRS-80 Microcolor Computer MC-10," was sold at Radio Shacks in the USA in the early 1980s, and was Tandy's attempt to compete with the Timex Sinclair 1000.

In the Mid-1980s, there was a push in France for computers to be connected and more prevalent.  The Alice 32 was Matra & Hachette's first offering for this push.  It sported a new video chip, the EF9345, which had many fine features for putting colored text and mini-graphics on the screen.  The Alice 32 was succeeded by the Alice 90, which had a video input line so the colored text and mini-graphics could overlay the external video!  This is one of two computers I've heard of which had this "genlocking" ability built in (the other was the Sony SMC-70G -- the Amiga doesn't count, 'cause it needed an external hardware add-on genlocker).  

The Alice 32 features a 6803 microcontroller acting as CPU and peripheral interface adapter.  It comes standard with 8K of main RAM, 8K of Video RAM, and 16K of ROM (8+8+16=32, hence the name Alice 32).  The ROM had been expanded from the MC-10's 8K to hold an assembler, and the video handling routines needed for the new 40- and 80-column text modes, and for simulating the MC-10's 32-column screen on the Alice 32's 40-column screen.

A +16K RAM expander was sold for this computer (the +16K adapter for the MC-10 works just fine too).  I suspect, but am not sure, that a +24K expander was sold.

A joystick adapter was sold, giving joystick input at memory locations $BF30 and $BF34.  I don't know if this could be plugged into an MC-10, and I recommend not trying it unless you have enough MC-10s and joystick adapters that you wouldn't mind frying a pair.

Several companies in France made games on cassette for the Alice 32.  Matra & Hachette encouraged software development, and more than a score of game and educational packages exist.

==

2.  What is an emulator?
	An emulator is a software program which enables one computer to act like another.  It'll emulate the graphics, peripherals, sound, timing, etc.  Ideally, the emulator will run pretty much everything the emulated computer could run, and provide a similar "experience."
	James's editorial:  I prefer a somewhat streamlined experience, and so my emulators generally incorporate Quicktype and Sensible Keyboard, and speed up for what would otherwise be overly tedious cassette I/O.  Let me know what you think.
