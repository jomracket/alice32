If you're using Notepad, turn on wordwrap.


.C10 files are MC-10 (and Alice) format cassette files.
K7 files are Alice 32/90 format cassette images which may contain more than one actual file.

To use them, type CLOAD [enter] on My First Alice32.

From the File menu, select Play Cassette File, and choose the .C10 or .K7 file you want.

NOTE:  Some of these files have been separated from their information and other useful files.  If you're interested in finding out more about a particular file, go see its "downloaded from" website!

====

squares.c10
From TRS-80 Color Computer Programs
page 224
(C) 1981 Tom Rugg and Phil Feldman


All K7 files were ripped off from http://alice32.free.fr/
For information on the K7 files, see these informative Alice 32 websites:
http://alice32.free.fr/
http://membres.lycos.fr/romualdl/alice/alice.html
http://ritchy.free.fr/_musee.html#

