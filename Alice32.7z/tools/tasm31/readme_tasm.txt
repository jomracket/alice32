This is only a very small subset of the
Telemark Cross Assembler package, but it's what's
needed to work with the 6803.

goasm.bat is a sample batch file for assembling
a source file to object (binary) for the 6803.
Without modification, it assembles the testasm.txt
file.
tasm -68 -b -x3 testasm.txt
invokes the tasm assembler
-b specifies binary (obj) output
     (this can be loaded into the emulator using
     the Util/Load Binary File)
-x3 specifies using the 6803 instead of the 6800
     (see the manual)
testasm.txt is the file to be assembled. 

MOTO.H is a set of defines for using the 
Telemark Assembler, to make the assembly
language more resemble Motorola's preferred
specification.

ORDERFRM.TXT is an order form for
registering the Telemark Assembler
(thereby getting the full package,
support, and updates).

TASM.EXE is the Telemark Assembler program.

TASM68.TAB is the table file used by the
Telemark Assembler program when assembling
6800 and 6803 assembly language files.

TASMAN.HTM is the manual for the
Telemark Cross Assembler package.

testasm.txt is a short assembly language
file for the 6803.  Indeed, it's the small
program that's poked by the memwina
program (see the Quicktyp directory).


