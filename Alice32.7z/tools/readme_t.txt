A few tools to help you work with the emulator.

========================

DC - Dragon Convert.  This is a program which will convert a WAV file to a CAS file.  You'll need an MS-DOS prompt to use it.  I've tried it with mono WAVs.  It works best if the WAV file you're using has an amplitude great enough so that most peaks clip.  Good luck.  DC messes with the synch bytes -- FIXCAS will fix those.  When using FIXCAS with MC-10 files, use synch parameters of 128 0 to output a C10 file

dc wavename
fixcas casname c10name 128 0

-
dc program by P.Burgin, 1997
========================

FIXCAS - see DC (Dragon Convert) above.

-
fixcas program by Graham E. Kinns, 1993
========================

MONOWAV - This program takes a stereo WAV file and cuts it into two mono WAV files.  The new mono WAV files are named name_ML.wav and name_MR.wav.

-
monowav program by James the Animal Tamer
========================

C10TOWAV - This program takes a good .c10 file and converts it into a WAV file.  The WAV file can be used with a real MC10 or Alice computer.  It's a Windows program -- double click the icon to open it and get started.

-
c10towav program by James the Animal Tamer
========================


